<?php

namespace App\Resolvers;

abstract class Resolver {
    // Common resolver functionalities can be defined here
}
